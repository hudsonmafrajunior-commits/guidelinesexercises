/**
 * R3H2B — Prescrição para Populações Especiais
 * Backend Google Apps Script
 *
 * Planilha criada automaticamente no Drive na primeira execução, com as abas:
 *  - Solicitações  : 1 linha por relatório salvo (o "relatório de solicitações")
 *  - Comorbidades  : 1 linha por condição de cada solicitação (para contagem)
 *  - Profissionais : cadastro único por WhatsApp (usado para autopreencher)
 *  - Painel        : contagens automáticas por profissional e por condição
 */

const CONFIG = {
  SPREADSHEET_NAME: 'R3H2B — Populações Especiais (banco de dados)',
  // Número que recebe cópia das solicitações (DDI+DDD+número, só dígitos). Deixe '' para ocultar o botão.
  ADMIN_WHATSAPP: '',
  ADMIN_NOME: 'R3H2B'
};

const HEAD_SOLIC = [
  'Data/hora', 'Protocolo', 'Profissional', 'WhatsApp profissional', 'Conselho', 'Nº registro', 'UF',
  'Cliente', 'Idade', 'Sexo', 'Peso (kg)', 'Altura (cm)', 'FC repouso', 'PA repouso',
  'Condições', 'Dados específicos', 'Betabloqueador', 'Dose (mg/dia)', 'FCmáx usada', 'Método FCmáx',
  'Zona aeróbia (bpm)', 'Força (%1RM)', 'Séries × reps', 'Descanso (s)', 'Alertas',
  'Técnica', 'Exercícios', 'Relatório (texto)'
];
const HEAD_PROF = ['WhatsApp', 'Nome completo', 'Conselho', 'Nº registro', 'UF', 'Primeira solicitação', 'Última solicitação', 'Total de solicitações'];
const HEAD_COMORB = ['Data/hora', 'Protocolo', 'Profissional', 'Cliente', 'Condição'];

function doGet() {
  return HtmlService.createHtmlOutputFromFile('Index')
    .setTitle('Prescrição — Populações Especiais')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

/* ---------- Planilha ---------- */

function getSS_() {
  const props = PropertiesService.getScriptProperties();
  const id = props.getProperty('SS_ID');
  if (id) {
    try { return SpreadsheetApp.openById(id); } catch (e) { /* recria abaixo */ }
  }
  const ss = SpreadsheetApp.create(CONFIG.SPREADSHEET_NAME);
  setup_(ss);
  props.setProperty('SS_ID', ss.getId());
  return ss;
}

function setup_(ss) {
  const first = ss.getSheets()[0];
  first.setName('Solicitações');
  styleHeader_(first, HEAD_SOLIC);

  styleHeader_(ss.insertSheet('Comorbidades'), HEAD_COMORB);
  styleHeader_(ss.insertSheet('Profissionais'), HEAD_PROF);

  const p = ss.insertSheet('Painel');
  p.getRange('A1').setValue('Solicitações por profissional').setFontWeight('bold');
  p.getRange('A2').setFormula("=IFERROR(QUERY('Solicitações'!A:C,\"select C, count(B) where B is not null group by C order by count(B) desc label count(B) 'Solicitações'\",1),\"—\")");
  p.getRange('D1').setValue('Solicitações por condição').setFontWeight('bold');
  p.getRange('D2').setFormula("=IFERROR(QUERY(Comorbidades!A:E,\"select E, count(B) where B is not null group by E order by count(B) desc label count(B) 'Casos'\",1),\"—\")");
  p.getRange('G1').setValue('Total de solicitações').setFontWeight('bold');
  p.getRange('G2').setFormula("=MAX(0,COUNTA('Solicitações'!B:B)-1)");
  p.setColumnWidths(1, 8, 170);
}

// Atualiza o cabeçalho de planilhas criadas em versões anteriores do app
function ensureHeaders_(sh, head) {
  const cur = sh.getLastColumn();
  if (cur >= head.length) return;
  sh.getRange(1, 1, 1, head.length).setValues([head])
    .setFontWeight('bold').setBackground('#E3F0EC').setFontColor('#16302B');
}

function styleHeader_(sh, head) {
  sh.getRange(1, 1, 1, head.length).setValues([head])
    .setFontWeight('bold').setBackground('#E3F0EC').setFontColor('#16302B');
  sh.setFrozenRows(1);
}

// Evita que textos iniciados por = + - @ virem fórmula
function safe_(v) {
  if (v === null || v === undefined) return '';
  const s = String(v);
  return /^[=+\-@]/.test(s) ? "'" + s : s;
}

function digits_(v) { return String(v || '').replace(/\D/g, ''); }

/* ---------- Funções chamadas pela página ---------- */

function getConfig() {
  return { adminWhatsapp: digits_(CONFIG.ADMIN_WHATSAPP), adminNome: CONFIG.ADMIN_NOME };
}

function getProfessional(whatsapp) {
  const wa = digits_(whatsapp);
  if (wa.length < 10) return null;
  const sh = getSS_().getSheetByName('Profissionais');
  const last = sh.getLastRow();
  if (last < 2) return null;
  const rows = sh.getRange(2, 1, last - 1, 5).getValues();
  for (let i = 0; i < rows.length; i++) {
    if (digits_(rows[i][0]) === wa) {
      return { whatsapp: wa, nome: rows[i][1], conselho: rows[i][2], registro: rows[i][3], uf: rows[i][4] };
    }
  }
  return null;
}

function saveRequest(p) {
  const lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    const ss = getSS_();
    const now = new Date();
    const prof = p.prof || {}, cli = p.cliente || {}, r = p.resumo || {};
    const wa = digits_(prof.whatsapp);

    const shS = ss.getSheetByName('Solicitações');
    ensureHeaders_(shS, HEAD_SOLIC);
    shS.appendRow([
      now, safe_(p.protocolo), safe_(prof.nome), wa, safe_(prof.conselho), safe_(prof.registro), safe_(prof.uf),
      safe_(cli.nome), cli.idade || '', safe_(cli.sexo), cli.peso || '', cli.altura || '', cli.fcrep || '', safe_(cli.pa),
      safe_((p.condicoes || []).join(', ')), safe_(p.especificos), safe_(p.bb), p.bbDose || '', r.fcmax || '', safe_(r.metodo),
      safe_(r.zona), safe_(r.rm), safe_(r.seriesReps), safe_(r.descanso), safe_(r.alertas),
      safe_(p.tecnica), safe_(p.exercicios), safe_(p.texto)
    ]);

    const cs = ss.getSheetByName('Comorbidades');
    (p.condicoes || []).forEach(function (c) {
      cs.appendRow([now, safe_(p.protocolo), safe_(prof.nome), safe_(cli.nome), safe_(c)]);
    });

    upsertProf_(ss.getSheetByName('Profissionais'), wa, prof, now);
    return { ok: true, protocolo: p.protocolo, url: ss.getUrl() };
  } finally {
    lock.releaseLock();
  }
}

function upsertProf_(sh, wa, prof, now) {
  const last = sh.getLastRow();
  if (last >= 2) {
    const ids = sh.getRange(2, 1, last - 1, 1).getValues();
    for (let i = 0; i < ids.length; i++) {
      if (digits_(ids[i][0]) === wa) {
        const row = i + 2;
        const total = Number(sh.getRange(row, 8).getValue()) || 0;
        sh.getRange(row, 2, 1, 4).setValues([[safe_(prof.nome), safe_(prof.conselho), safe_(prof.registro), safe_(prof.uf)]]);
        sh.getRange(row, 7, 1, 2).setValues([[now, total + 1]]);
        return;
      }
    }
  }
  sh.appendRow([wa, safe_(prof.nome), safe_(prof.conselho), safe_(prof.registro), safe_(prof.uf), now, now, 1]);
}

/** Rode uma vez pelo editor para autorizar e ver o link da planilha no log. */
function setupInicial() {
  const ss = getSS_();
  Logger.log('Planilha: ' + ss.getUrl());
}
